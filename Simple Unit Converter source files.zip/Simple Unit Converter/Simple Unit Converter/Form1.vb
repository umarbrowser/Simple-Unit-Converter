﻿Public Class Form1

     Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LenthList1.SelectedIndexChanged
     End Sub

     Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
          LenthList1.SelectedItem = "Select From..."
          LenthList2.SelectedItem = "Select From"
     End Sub

     Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn_check_length.Click
          'Declare variable to hold our selected values 
          Dim num1_length, num2_length As String
          Dim KM1, M1, CM1 As Boolean
          Dim KM2, M2, CM2 As Boolean

          'initialize the variable 
          num1_length = UnitText1_length.Text
          num2_length = UnitText2_length.Text

          If LenthList1.Text = ("Kilometer") And LenthList2.Text = ("Meter") Then
               KM1 = True
               M2 = True
          End If

          If KM1 = True And M2 = True Then
               UnitText2_length.Text = num1_length / 0.001
          End If

          If LenthList1.Text = ("Kilometer") And LenthList2.Text = ("Centimeter") Then
               KM1 = True
               CM2 = True
          End If

          If KM1 = True And CM2 = True Then
               UnitText2_length.Text = num1_length / 0.00001
          End If

          If LenthList1.Text = ("Meter") And LenthList2.Text = ("Kilometer") Then
               M1 = True
               KM2 = True
          End If

          If M1 = True And KM2 = True Then
               UnitText2_length.Text = num1_length / 1000
          End If

          If LenthList1.Text = ("Meter") And LenthList2.Text = ("Centimeter") Then

               M1 = True
               CM2 = True
          End If

          If M1 = True And CM2 = True Then
               UnitText2_length.Text = num1_length / 0.01
          End If

          If LenthList1.Text = ("Centimeter") And LenthList2.Text = ("Kilometer") Then
               CM1 = True
               KM2 = True
          End If

          If CM1 = True And KM2 = True Then
               UnitText2_length.Text = num1_length * 0.00001
          End If

          If LenthList1.Text = ("Centimeter") And LenthList2.Text = ("Meter") Then
               CM1 = True
               M2 = True
          End If

          If CM1 = True And M2 = True Then
               UnitText2_length.Text = num1_length * 0.01
          End If

          If LenthList1.Text = LenthList2.Text Then
               UnitText2_length.Text = num1_length
               'MessageBox.Show("Opps! The Selected values are The same ", "WARNING",
               'MessageBoxButtons.OK, MessageBoxIcon.Warning)
          End If
     End Sub

     Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
          'Good bye message
          'MessageBox.Show("Thank You For Your Time", "Thank You", MessageBoxButtons.OK,
          'MessageBoxIcon.Information)
          Me.Close()

     End Sub

     Private Sub btn_check_mass_Click(sender As Object, e As EventArgs) Handles btn_check_mass.Click
          'Declare variable to hold our selected values 
          Dim num1_mass, num2_mass As String
          Dim TO1, KG1, GR1 As Boolean
          Dim TO2, KG2, GR2 As Boolean

          'initialize the variable 
          num1_mass = UnitText1_mass.Text
          num2_mass = UnitText2_mass.Text

          'Ton
          'Kilogram
          'Gram

          If MassList1.Text = ("Ton") And MassList2.Text = ("Kilogram") Then
               TO1 = True
               KG2 = True
          End If

          If TO1 = True And KG2 = True Then
               UnitText2_mass.Text = num1_mass * 1000
          End If

          If MassList1.Text = ("Ton") And MassList2.Text = ("Gram") Then
               TO1 = True
               GR2 = True
          End If

          If TO1 = True And GR2 = True Then
               UnitText2_mass.Text = num1_mass * 1000000
          End If

          If MassList1.Text = ("Kilogram") And MassList2.Text = ("Ton") Then
               KG1 = True
               TO2 = True
          End If

          If KG1 = True And TO2 = True Then
               UnitText2_mass.Text = num1_mass / 1000
          End If

          If MassList1.Text = ("Kilogram") And MassList2.Text = ("Gram") Then
               KG1 = True
               GR2 = True
          End If

          If KG1 = True And GR2 = True Then
               UnitText2_mass.Text = num1_mass / 100
          End If

          If MassList1.Text = ("Gram") And MassList2.Text = ("Ton") Then
               GR1 = True
               TO2 = True
          End If

          If GR1 = True And TO2 = True Then
               UnitText2_mass.Text = num1_mass / 1000000
          End If

          If MassList1.Text = ("Gram") And MassList2.Text = ("Kilogram") Then
               GR1 = True
               KG2 = True
          End If

          If GR1 = True And KG2 = True Then
               UnitText2_mass.Text = num1_mass / 1000
          End If

          If MassList1.Text = MassList2.Text Then
               UnitText2_mass.Text = num1_mass
               'MessageBox.Show("Opps! The Selected values are The same ", "WARNING",
               'MessageBoxButtons.OK, MessageBoxIcon.Warning)
          End If

         
     End Sub

     Private Sub btn_check_temp_Click(sender As Object, e As EventArgs) Handles btn_check_temp.Click
          'Declare variable to hold our selected values 
          Dim num1_temp, num2_temp As String
          Dim CE1, FA1, KE1 As Boolean
          Dim CE2, FA2, KE2 As Boolean

          'initialize the variable 
          num1_temp = UnitText1_temp.Text
          num2_temp = UnitText2_temp.Text
          'Celsius
          'Fahrenheit
          'Kelvin
          If TempList1.Text = ("Celsius") And TempList2.Text = ("Fahrenheit") Then
               CE1 = True
               FA2 = True
          End If

          If CE1 = True And FA2 = True Then
               UnitText2_temp.Text = ((num1_temp * (9 / 5)) + 32)
          End If

          If TempList1.Text = ("Celsius") And TempList2.Text = ("Kelvin") Then
               CE1 = True
               KE2 = True
          End If

          If CE1 = True And KE2 = True Then
               UnitText2_temp.Text = num1_temp + 273.15
          End If

          If TempList1.Text = ("Fahrenheit") And TempList2.Text = ("Celsius") Then
               FA1 = True
               CE2 = True
          End If

          If FA1 = True And CE2 = True Then
               UnitText2_temp.Text = ((num1_temp - 32) * (5 / 9))
          End If

          If TempList1.Text = ("Fahrenheit") And TempList2.Text = ("Kelvin") Then
               FA1 = True
               KE2 = True
          End If

          If FA1 = True And KE2 = True Then
               UnitText2_temp.Text = ((num1_temp - 32) * (5 / 9) + 273.15)
          End If

          If TempList1.Text = ("Kelvin") And TempList2.Text = ("Celsius") Then
               KE1 = True
               CE2 = True
          End If

          If KE1 = True And CE2 = True Then
               UnitText2_temp.Text = (num1_temp - 273.15)
          End If

          If TempList1.Text = ("Kelvin") And TempList2.Text = ("Fahrenheit") Then
               KE1 = True
               FA2 = True
          End If

          If KE1 = True And FA2 = True Then
               UnitText2_temp.Text = ((num1_temp - 273.15) * (9 / 5) + 32)
          End If

          If TempList1.Text = TempList2.Text Then
               UnitText2_temp.Text = num1_temp
               'MessageBox.Show("Opps! The Selected values are The same ", "WARNING",
               'MessageBoxButtons.OK, MessageBoxIcon.Warning)
          End If

          
     End Sub

     Private Sub PictureBox2_Click(sender As Object, e As EventArgs)

     End Sub

     Private Sub PictureBox1_Click(sender As Object, e As EventArgs)

     End Sub

     Private Sub PictureBox3_Click(sender As Object, e As EventArgs)

     End Sub
End Class
